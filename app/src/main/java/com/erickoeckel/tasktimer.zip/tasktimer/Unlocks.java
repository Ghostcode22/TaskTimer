package com.erickoeckel.tasktimer;

import java.util.Map;

public final class Unlocks {
    private Unlocks() {}

    private static boolean has(Map<String, Boolean> u, String key) {
        return u != null && Boolean.TRUE.equals(u.get(key));
    }

    public static boolean hairUnlocked(Map<String, Boolean> u, String hairSlug) {
        if (hairSlug == null) return false;
        if ("NoHair".equals(hairSlug)) return true;
        if (isHatTop(hairSlug) || isHeadCover(hairSlug)) return true;
        return has(u, "pack.hair");
    }

    public static boolean glassesUnlocked(Map<String, Boolean> u, String accSlug) {
        if (accSlug == null) return false;
        if ("Blank".equals(accSlug)) return true;
        return has(u, "pack.glasses");
    }

    public static boolean clothesUnlocked(Map<String, Boolean> u, String clotheType) {
        if (clotheType == null) return false;
        if (clotheType.startsWith("Shirt") || "BlazerShirt".equals(clotheType) || "BlazerSweater".equals(clotheType)
                || "CollarSweater".equals(clotheType) || "Overall".equals(clotheType)) {
            return true;
        }
        return has(u, "pack.clothes");
    }

    public static boolean graphicUnlocked(Map<String, Boolean> u, String graphic) {
        if (graphic == null) return false;
        return has(u, "pack.graphics");
    }

    public static boolean hairColorUnlocked(Map<String, Boolean> u, String color) {
        if (color == null) return false;
        if ("BrownDark".equals(color) || "Black".equals(color) || "Brown".equals(color)) return true;
        return has(u, "pack.colors");
    }
    public static boolean facialHairUnlocked(Map<String, Boolean> unlocks, String facialHairSlug) {
        if (facialHairSlug == null || "Blank".equals(facialHairSlug)) return true;
        return has(unlocks, "facialHair:" + facialHairSlug);
    }

    public static boolean facialHairColorUnlocked(Map<String, Boolean> u, String color) {
        if (color == null) return false;
        if ("BrownDark".equals(color) || "Black".equals(color) || "Brown".equals(color)) return true;
        return has(u, "pack.colors");
    }

    public static boolean clothesColorUnlocked(Map<String, Boolean> u, String color) {
        if (color == null) return false;
        if ("Black".equals(color) || color.startsWith("Gray")) return true;
        return has(u, "pack.colors");
    }

    public static boolean skinUnlocked(Map<String, Boolean> u, String skin) {
        return true;
    }

    private static boolean isHeadCover(String top) {
        return "Hijab".equals(top) || "Turban".equals(top);
    }
    private static boolean isHatTop(String topType) {
        return "Hat".equals(topType) || (topType != null && topType.startsWith("WinterHat"));
    }
}
