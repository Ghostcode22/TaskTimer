package com.erickoeckel.tasktimer;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.ListenerRegistration;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

public class ShopViewModel extends ViewModel {
    private final FirebaseFirestore db = FirebaseFirestore.getInstance();
    private final FirebaseAuth auth = FirebaseAuth.getInstance();

    private final MutableLiveData<Integer> _coins = new MutableLiveData<>(0);
    private final MutableLiveData<Map<String, Boolean>> _unlocks = new MutableLiveData<>(new HashMap<>());
    private ListenerRegistration reg;

    public LiveData<Integer> coins()   { return _coins; }
    public LiveData<Map<String, Boolean>> unlocks() { return _unlocks; }

    public void start() {
        if (auth.getCurrentUser() == null) return;
        if (reg != null) return;
        reg = db.collection("users").document(auth.getCurrentUser().getUid())
                .addSnapshotListener((snap, e) -> {
                    if (e != null || snap == null) return;
                    applyUserSnapshot(snap);
                });
    }

    private void applyUserSnapshot(DocumentSnapshot snap) {
        Number c = (Number) snap.get("coins");
        _coins.setValue(c == null ? 0 : c.intValue());

        Map<String, Boolean> u = new HashMap<>();
        Object raw = snap.get("unlocks");
        if (raw instanceof Map) {
            u.putAll((Map<String, Boolean>) raw);
        }
        _unlocks.setValue(u);
    }

    @Override protected void onCleared() {
        if (reg != null) { reg.remove(); reg = null; }
    }

    public void purchase(@NonNull ShopItem item,
                         @NonNull Runnable onOk,
                         @NonNull Consumer<String> onErr) {

        FirebaseUser u = FirebaseAuth.getInstance().getCurrentUser();
        if (u == null) { onErr.accept("Not signed in"); return; }

        FirebaseFirestore db = FirebaseFirestore.getInstance();
        DocumentReference userRef = db.collection("users").document(u.getUid());

        db.runTransaction(tr -> {
                    DocumentSnapshot snap = tr.get(userRef);

                    long coins = 0L;
                    Long c = snap.getLong("coins");
                    if (c != null) coins = c;

                    @SuppressWarnings("unchecked")
                    Map<String, Object> unlocks = (Map<String, Object>) snap.get("unlocks");
                    if (unlocks == null) unlocks = new HashMap<>();

                    boolean alreadyOwned = Boolean.TRUE.equals(unlocks.get(item.unlockKey));
                    if (alreadyOwned) {
                        throw new FirebaseFirestoreException(
                                "Already owned", FirebaseFirestoreException.Code.ABORTED);
                    }

                    if (coins < item.price) {
                        throw new FirebaseFirestoreException(
                                "Not enough coins", FirebaseFirestoreException.Code.ABORTED);
                    }

                    tr.update(userRef, "coins", FieldValue.increment(-item.price));

                    tr.update(userRef, "unlocks." + item.unlockKey, true);

                    if (item.includes != null) {
                        for (String slug : item.includes) {
                            tr.update(userRef, "unlocks." + slug, true);
                        }
                    }

                    return null;
                }).addOnSuccessListener(v -> onOk.run())
                .addOnFailureListener(e -> onErr.accept(e.getMessage() == null ? "" : e.getMessage()));
    }


}
