package com.erickoeckel.tasktimer;

import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.Arrays;
import java.util.List;

public class ShopFragment extends Fragment {

    private TextView tvCoins;
    private RecyclerView rv;
    private ShopAdapter adapter;
    private ShopViewModel vm;

    private static final List<ShopItem> CATALOG = Arrays.asList(
            new ShopItem("pack.hair",     "Hair Styles Pack",     "Unlocks all premium hair styles.",             200,
                    Arrays.asList("LongHairBigHair", "LongHairFroBand", "ShortHairShaggyMullet")),
            new ShopItem("pack.glasses",  "Glasses Pack",         "Unlocks sunglasses & premium frames.",         150,
                    Arrays.asList("Sunglasses", "Wayfarers", "Round")),
            new ShopItem("pack.clothes",  "Clothes Pack",         "Unlocks hoodies & premium shirts.",            150,
                    Arrays.asList("Hoodie", "ShirtScoopNeck")),
            new ShopItem("pack.graphics", "Graphic Tees Pack",    "Unlocks all shirt graphics.",                   120,
                    Arrays.asList("Bear", "Cumbia", "SkullOutline", "Pizza")),
            new ShopItem("pack.colors",   "Color Pack",           "Unlocks premium hair/facial/clothes colors.",  120,
                    Arrays.asList("SilverGray", "PastelPink", "Heather"))
    );

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inf, @Nullable ViewGroup parent, @Nullable Bundle b) {
        View v = inf.inflate(R.layout.fragment_shop, parent, false);
        tvCoins = v.findViewById(R.id.tvCoins);
        rv = v.findViewById(R.id.rvShop);

        vm = new ViewModelProvider(this).get(ShopViewModel.class);

        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        rv.addItemDecoration(new DividerItemDecoration(requireContext(), DividerItemDecoration.VERTICAL));

        adapter = new ShopAdapter(item ->
                vm.purchase(
                        item,
                        () -> Toast.makeText(requireContext(), "Purchased " + item.title + "!", Toast.LENGTH_SHORT).show(),
                        (String err) -> Toast.makeText(
                                requireContext(),
                                (err == null || err.trim().isEmpty()) ? "Purchase failed" : err,
                                Toast.LENGTH_LONG
                        ).show()
                )
        );


        rv.setAdapter(adapter);

        vm.coins().observe(getViewLifecycleOwner(), coins -> {
            int c = (coins == null) ? 0 : coins;
            tvCoins.setText(c + " 🪙");
            adapter.submit(CATALOG, vm.unlocks().getValue(), c);
        });
        vm.unlocks().observe(getViewLifecycleOwner(), unlocks -> {
            Integer coins = vm.coins().getValue();
            adapter.submit(CATALOG, unlocks, coins == null ? 0 : coins);
        });

        vm.start();
        return v;
    }
}
