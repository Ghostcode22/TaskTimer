package com.erickoeckel.tasktimer;

import java.util.List;

public class ShopItem {
    public final String unlockKey;
    public final String title;
    public final String desc;
    public final int price;
    public final List<String> includes;

    public ShopItem(String key, String t, String d, int p, List<String> inc) {
        unlockKey = key; title = t; desc = d; price = p; includes = inc;
    }
}
