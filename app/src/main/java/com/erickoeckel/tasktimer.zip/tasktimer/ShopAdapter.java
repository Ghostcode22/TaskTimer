package com.erickoeckel.tasktimer;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ShopAdapter extends RecyclerView.Adapter<ShopAdapter.VH> {

    public interface BuyClick { void onBuy(ShopItem item); }

    private final BuyClick onBuy;
    private final List<ShopItem> items = new ArrayList<>();
    private Map<String, Boolean> owned;
    private int coinBalance = 0;

    public ShopAdapter(@NonNull BuyClick onBuy) { this.onBuy = onBuy; }

    public void submit(List<ShopItem> src, Map<String, Boolean> owned, int coins) {
        items.clear();
        if (src != null) items.addAll(src);
        this.owned = owned;
        this.coinBalance = coins;
        notifyDataSetChanged();
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View row = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_shop_item, parent, false);
        return new VH(row);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        ShopItem it = items.get(pos);
        boolean isOwned = owned != null && Boolean.TRUE.equals(owned.get(it.unlockKey));

        String title = it.title + (isOwned ? "  ✓" : "");
        h.title.setText(title);

        String subtitle = "Price: " + it.price + " 🪙"
                + "\n" + it.desc
                + (it.includes != null && !it.includes.isEmpty()
                ? "\nUnlocks: " + TextUtils.join(", ", it.includes)
                : "");
        h.subtitle.setText(subtitle);

        h.buy.setText(isOwned ? "Owned" : "Buy");
        boolean canBuy = !isOwned && coinBalance >= it.price;
        h.buy.setEnabled(canBuy);
        h.buy.setAlpha(canBuy ? 1f : 0.5f);
        h.buy.setOnClickListener(v -> { if (canBuy) onBuy.onBuy(it); });
    }

    @Override
    public int getItemCount() { return items.size(); }

    static class VH extends RecyclerView.ViewHolder {
        final TextView title, subtitle;
        final MaterialButton buy;
        VH(@NonNull View itemView) {
            super(itemView);
            title = itemView.findViewById(R.id.tvItemTitle);
            subtitle = itemView.findViewById(R.id.tvItemSubtitle);
            buy = itemView.findViewById(R.id.btnBuy);
        }
    }
}
