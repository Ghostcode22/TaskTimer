package com.erickoeckel.tasktimer;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.button.MaterialButtonToggleGroup;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.UserProfileChangeRequest;

public class AuthActivity extends AppCompatActivity {
    private TextInputEditText etEmail, etPassword, etUsername;
    private TextInputLayout tilUsername;
    private MaterialButton btnSubmit;
    private MaterialButtonToggleGroup toggle;
    private ProgressBar progress;
    private TextView tvError;
    private boolean isRegister = false;
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        tilUsername = findViewById(R.id.tilUsername);
        etUsername  = findViewById(R.id.etUsername);
        btnSubmit = findViewById(R.id.btnSubmit);
        toggle = findViewById(R.id.toggleMode);
        progress = findViewById(R.id.progress);
        tvError = findViewById(R.id.tvError);

        toggle.addOnButtonCheckedListener((group, checkedId, isChecked) -> {
            if (!isChecked) return;
            isRegister = (checkedId == R.id.btnRegisterMode);
            btnSubmit.setText(isRegister ? "Create Account" : "Login");
            if (tilUsername != null) {
                tilUsername.setVisibility(isRegister ? View.VISIBLE : View.GONE);
            }
            tvError.setVisibility(View.GONE);
        });

        btnSubmit.setOnClickListener(v -> submit());
    }

    private void submit() {
        String email = Objects.toString(etEmail.getText(), "").trim();
        String pass = Objects.toString(etPassword.getText(), "").trim();
        String username = "";

        if (isRegister && etUsername != null) {
            username = Objects.toString(etUsername.getText(), "").trim();
            if (username.isEmpty()) {
                showError("Please choose a username.");
                setLoading(false);
                return;
            }
        }

        if (email.isEmpty() || pass.isEmpty()) {
            showError("Email and password required.");
            return;
        }

        setLoading(true);

        if (isRegister) {
            final String chosenUsername = username; // ✅ make it final for lambdas

            auth.createUserWithEmailAndPassword(email, pass)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            FirebaseUser user = auth.getCurrentUser();
                            if (user != null) {
                                Map<String,Object> base = new HashMap<>();
                                base.put("email", user.getEmail());
                                base.put("xp", 0L);
                                base.put("coins", 0L);
                                base.put("createdAt", FieldValue.serverTimestamp());
                                base.put("username", chosenUsername);
                                base.put("displayName", chosenUsername);
                                base.put("avatarConfig", new AvatarConfig().toMap());

                                user.updateProfile(new UserProfileChangeRequest.Builder()
                                        .setDisplayName(chosenUsername)
                                        .build());

                                db.collection("users").document(user.getUid()).set(base, SetOptions.merge());
                                db.collection("users").document(user.getUid())
                                        .set(base, SetOptions.merge())
                                        .addOnSuccessListener(unused -> goToApp())
                                        .addOnFailureListener(e -> {
                                            showError("Account created, but profile save failed: " + e.getMessage());
                                            goToApp();
                                        });
                            } else {
                                goToApp();
                            }
                        } else {
                            showError(Objects.requireNonNull(task.getException()).getMessage());
                            setLoading(false);
                        }
                    });
        } else {
            auth.signInWithEmailAndPassword(email, pass)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            goToApp();
                        } else {
                            showError(Objects.requireNonNull(task.getException()).getMessage());
                            setLoading(false);
                        }
                    });
        }
    }

    private void goToApp() {
        setLoading(false);
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }

    private void showError(String msg) {
        tvError.setText(msg);
        tvError.setVisibility(View.VISIBLE);
    }

    private void setLoading(boolean b) {
        progress.setVisibility(b ? View.VISIBLE : View.GONE);
        btnSubmit.setEnabled(!b);
        toggle.setEnabled(!b);
        etEmail.setEnabled(!b);
        etPassword.setEnabled(!b);
        if (etUsername != null) etUsername.setEnabled(!b);
    }
}

